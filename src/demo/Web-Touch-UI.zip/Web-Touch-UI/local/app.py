import socketio
import tkinter as tk
import threading

# Tkinter setup
root = tk.Tk()
root.title("Cursor Tracker")

# Tkinter canvas dimensions
canvas_width = 800
canvas_height = 600

canvas = tk.Canvas(root, width=canvas_width, height=canvas_height, bg="white")
canvas.pack()

# Global variables for cursor position and color
cursor_x = canvas_width / 2  # Start at center
cursor_y = canvas_height / 2  # Start at center
cursor_color = "red"
cursor_visible = False  # Cursor visibility flag

def update_tkinter_canvas():
    canvas.delete("all")
    if cursor_visible:
        cursor_radius = 10  # Cursor size
        canvas.create_oval(
            cursor_x - cursor_radius, cursor_y - cursor_radius,
            cursor_x + cursor_radius, cursor_y + cursor_radius,
            fill=cursor_color
        )
    canvas.update()

# SocketIO client setup
sio = socketio.Client()

@sio.event
def connect():
    print('Connected to server')
    sio.emit('register_app')

@sio.event
def disconnect():
    print('Disconnected from server')

@sio.on('cursor_move')
def on_cursor_move(data):
    global cursor_x, cursor_y
    delta_x = data.get('deltaX', 0)
    delta_y = data.get('deltaY', 0)
    sensitivity = 2.0  # Adjust sensitivity as needed

    cursor_x += delta_x * sensitivity
    cursor_y += delta_y * sensitivity

    # Ensure cursor stays within bounds
    cursor_x = max(0, min(canvas_width, cursor_x))
    cursor_y = max(0, min(canvas_height, cursor_y))

    # Update the GUI in the main thread
    root.after(0, update_tkinter_canvas)

@sio.on('tap')
def on_tap(data):
    global cursor_color
    cursor_color = "blue" if cursor_color == "red" else "red"

    # Update the GUI in the main thread
    root.after(0, update_tkinter_canvas)

@sio.on('show_cursor')
def on_show_cursor():
    global cursor_visible
    cursor_visible = True
    print("Received 'show_cursor' event")
    root.after(0, update_tkinter_canvas)

@sio.on('hide_cursor')
def on_hide_cursor():
    global cursor_visible
    cursor_visible = False
    print("Received 'hide_cursor' event")
    root.after(0, update_tkinter_canvas)

def start_socketio_client():
    # Replace my heroku app name with your own
    sio.connect('https://web-touch-676c733c3421.herokuapp.com')
    sio.wait()

# Start the SocketIO client in a separate thread
socketio_thread = threading.Thread(target=start_socketio_client)
socketio_thread.daemon = True
socketio_thread.start()

# Start the Tkinter event loop
root.mainloop()
