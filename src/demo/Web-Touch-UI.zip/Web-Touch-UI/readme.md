# Canvas Touch and Tap WebSocket Integration

This project demonstrates a real-time interactive interface that integrates a web-based HTML5 Canvas with a Python backend using Flask-SocketIO and a local Tkinter application. The HTML5 Canvas captures cursor movements and taps, transmitting these interactions via WebSockets to a Python app that visualizes them on a Tkinter canvas.

---

## Live Instance

The live instance of the server is hosted on Heroku. You can access it here:

- **Live Heroku App**: [https://web-touch-676c733c3421.herokuapp.com](https://web-touch-676c733c3421.herokuapp.com)

---

## Project Structure

The project is organized as follows:

```
/your-project-folder
│
├── local/
│   ├── app.py               # Local Tkinter application
│   └── requirements.txt     # Python dependencies for the local environment
│
├── heroku/
│   ├── server.py            # Flask-SocketIO server
│   ├── static/
│   │   └── index.html       # HTML page with Canvas and WebSocket logic
│   ├── requirements.txt     # Python dependencies for Heroku
│   └── Procfile             # Process file for Heroku deployment
```

---

## Motivation

The goal is to showcase the integration of a web-based interface and a Python GUI application for real-time data exchange. This modular approach enhances scalability and maintainability and demonstrates how WebSocket technology can enable seamless interaction between web and local applications.

### Features

- **Web-Based Client**: Uses HTML5 Canvas to capture cursor movements and tap events.
- **Flask-SocketIO Server**: Manages real-time communication between the client and the app.
- **Local Tkinter App**: Visualizes cursor movements and tap events on a canvas.
- **Dynamic Cursor Visibility**: The cursor appears or disappears based on client connections.
- **Relative Cursor Movement**: Simulates a trackpad-like behavior for smoother interaction.

---

## Installation and Running the Project Locally

### Step 1: Clone the Repository

```bash
git clone https://github.com/your-username/webtouch.git
cd webtouch
```

### Step 2: Set Up a Virtual Environment

**Create and activate a virtual environment**:

- **macOS/Linux**:

  ```bash
  python -m venv venv
  source venv/bin/activate
  ```

- **Windows**:

  ```bash
  python -m venv venv
  venv\Scripts\activate
  ```

### Step 3: Install Python Dependencies

Navigate to the `local` directory and install the required packages:

```bash
cd local
pip install -r requirements.txt --no-user
```

> **Note**: Ensure `tkinter` is installed on your system. 


### Step 4: Running the Project

1. **Run the Tkinter App**:

   ```bash
   python app.py
   ```

   The Tkinter app will connect to the Heroku-hosted server at `https://web-touch-676c733c3421.herokuapp.com/`.

2. **Access the Web Client**:

   Open your web browser and navigate to `https://web-touch-676c733c3421.herokuapp.com`.

---

## Usage

### Cursor Movement

- **Desktop Devices**: Click and drag on the Canvas to move the dot on the Tkinter app.
- **Touch Devices**: Use a single finger to move the cursor.

### Tap Events

- **Desktop Devices**: Perform a right-click or a two-finger click to toggle the dot color.
- **Touch Devices**: Perform a two-finger tap to toggle the dot color.

### Cursor Visibility

The cursor in the Tkinter app only appears when at least one client is connected. It hides when all clients disconnect.

---

## How It Works

### Interaction Flow

1. **Client (`index.html`)**: Sends cursor movements and tap events to the server.
2. **Server (`server.py`)**: Relays events to the Tkinter app and manages client connections.
3. **App (`app.py`)**: Updates the cursor position and color based on events from the server.

### Event Handling

- **Cursor Movement**: The client sends `cursor_move` events to the server, which are relayed to the Tkinter app.
- **Tap Events**: Toggle the dot color in the Tkinter app.
- **Cursor Visibility**: The Tkinter app shows or hides the cursor based on client connections.

