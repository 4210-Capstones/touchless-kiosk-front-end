import os
from flask import Flask, request, send_from_directory
from flask_socketio import SocketIO, emit

app = Flask(__name__, static_url_path='', static_folder='static')
# Use 'eventlet' for async_mode as recommended for production
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Route to serve index.html
@app.route('/')
def index():
    return app.send_static_file('index.html')

# Global variables
app_sid = None  # To store the sid of the app client
web_clients = set()  # To store the sids of web clients

@socketio.on('connect')
def handle_connect():
    print(f'Client connected: {request.sid}')
    # Wait for the client to identify itself

@socketio.on('disconnect')
def handle_disconnect():
    global app_sid
    if request.sid == app_sid:
        print("App client disconnected")
        app_sid = None
    elif request.sid in web_clients:
        print(f"Web client disconnected: {request.sid}")
        web_clients.remove(request.sid)
        # If no more web clients, tell the app to hide the cursor
        if not web_clients and app_sid:
            print("No more web clients connected. Sending 'hide_cursor' to app.")
            socketio.emit('hide_cursor', room=app_sid)
    else:
        print("Unknown client disconnected")

@socketio.on('register_app')
def handle_register_app():
    global app_sid
    app_sid = request.sid
    print(f'App client registered with sid: {app_sid}')
    # If there are web clients connected, tell the app to show the cursor
    if web_clients:
        print("Web clients are connected. Sending 'show_cursor' to app.")
        socketio.emit('show_cursor', room=app_sid)

@socketio.on('register_web_client')
def handle_register_web_client():
    web_clients.add(request.sid)
    print(f'Web client registered with sid: {request.sid}')
    # Since a web client connected, tell the app to show the cursor
    if app_sid:
        print("Sending 'show_cursor' to app.")
        socketio.emit('show_cursor', room=app_sid)

@socketio.on('cursor_move')
def handle_cursor_move(data):
    # Broadcast the cursor movement to all connected clients except the sender
    emit('cursor_move', data, broadcast=True, include_self=False)

@socketio.on('tap')
def handle_tap(data):
    emit('tap', data, broadcast=True, include_self=False)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    socketio.run(app, host='0.0.0.0', port=port)
